from flask import Flask, render_template, request
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

df = pd.read_csv("games.csv")

tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(df['description'])

cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

def recommend(game_name):
    if game_name not in df['title'].values:
        return ["Game not found"]

    idx = df[df['title'] == game_name].index[0]
    selected_genre = df.iloc[idx]['genre']

    scores = list(enumerate(cosine_sim[idx]))

    boosted_scores = []
    for i, score in scores:
        genre = df.iloc[i]['genre']
        if genre == selected_genre:
            score += 0.2
        boosted_scores.append((i, score))

    boosted_scores = sorted(boosted_scores, key=lambda x: x[1], reverse=True)[1:6]

    results = []
    for i in boosted_scores:
        game_title = df['title'].iloc[i[0]]
        similarity = round(i[1], 2)
        results.append(f"{game_title} (Similarity: {similarity})")

    return results

@app.route('/', methods=['GET', 'POST'])
def home():
    recommendations = []
    selected_game = None

    if request.method == 'POST':
        selected_game = request.form['game']
        recommendations = recommend(selected_game)

    return render_template(
        'index.html',
        games=df['title'].tolist(),
        recs=recommendations,
        selected_game=selected_game
    )

if __name__ == '__main__':
    app.run(debug=True)